package model;

public class LoaiSP {

	private int id;
	private String maloaiSP;
	private String tenloadSP;
	public LoaiSP() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMaloaiSP() {
		return maloaiSP;
	}
	public void setMaloaiSP(String maloaiSP) {
		this.maloaiSP = maloaiSP;
	}
	public String getTenloadSP() {
		return tenloadSP;
	}
	public void setTenloadSP(String tenloadSP) {
		this.tenloadSP = tenloadSP;
	}
}
