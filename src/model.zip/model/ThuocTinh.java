package model;

public class ThuocTinh {

	private int id;
	private String tenthuoctinh;
	private String giatri;
	public ThuocTinh() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTenthuoctinh() {
		return tenthuoctinh;
	}
	public void setTenthuoctinh(String tenthuoctinh) {
		this.tenthuoctinh = tenthuoctinh;
	}
	public String getGiatri() {
		return giatri;
	}
	public void setGiatri(String giatri) {
		this.giatri = giatri;
	}	
}
