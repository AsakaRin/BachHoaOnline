package model;

public class NhomNCC {

	private int id;
	private String manhomNCC;
	private String tennhomNCC;
	public NhomNCC() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getManhomNCC() {
		return manhomNCC;
	}
	public void setManhomNCC(String manhomNCC) {
		this.manhomNCC = manhomNCC;
	}
	public String getTennhomNCC() {
		return tennhomNCC;
	}
	public void setTennhomNCC(String tennhomNCC) {
		this.tennhomNCC = tennhomNCC;
	}
}
