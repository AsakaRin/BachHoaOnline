package model;

public class NhomSP {

	private int id;
	private String manhomSP;
	private String tennhomSP;
	public NhomSP() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getManhomSP() {
		return manhomSP;
	}
	public void setManhomSP(String manhomSP) {
		this.manhomSP = manhomSP;
	}
	public String getTennhomSP() {
		return tennhomSP;
	}
	public void setTennhomSP(String tennhomSP) {
		this.tennhomSP = tennhomSP;
	}
}
