package model;

public class DiaChi {

	private int id;
	private String quanhuyen;
	private String tinhthanhpho;
	private String diachichitiet;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTinhthanhpho() {
		return tinhthanhpho;
	}
	public void setTinhthanhpho(String tinhthanhpho) {
		this.tinhthanhpho = tinhthanhpho;
	}
	public String getQuanhuyen() {
		return quanhuyen;
	}
	public void setQuanhuyen(String quanhuyen) {
		this.quanhuyen = quanhuyen;
	}
	public String getDiachichitiet() {
		return diachichitiet;
	}
	public void setDiachichitiet(String diachichitiet) {
		this.diachichitiet = diachichitiet;
	}
}
